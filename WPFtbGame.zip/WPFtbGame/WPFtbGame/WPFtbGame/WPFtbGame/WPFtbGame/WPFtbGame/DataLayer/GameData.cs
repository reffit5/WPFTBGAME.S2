﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections.ObjectModel;
using WPFtbGame.Models;

namespace WPFtbGame.DataLayer
{
    public class GameData
    {

        public static Player PlayerData()
        {
            return new Player()
            {
                Id = 1,
                DogName = "Alfred",
                Age = 12,
                Health = 100,
                Lives = 1,
                typeOfDog = Character.TypeOfDog.Doxin,
                DogImage = "dog.jpg",
                LocationId = 0


            };
        }

        public static List<string> InitalizeMessage()
        {
            return new List<string>()
            {
                "You are Lost in the park and need to find your way back home."
        };
        }

        public static GameMapCoorinates InitialGameMapLocation()
        {
            return new GameMapCoorinates() { Row = 0, Column = 0 };
        }

        public static Map GameMap()
        {
            int rows = 3;
            int columns = 4;

            Map gameMap = new Map(rows, columns);

            gameMap.MapLocation[0, 0] = new Location()
            {
                Id = 4,
                Name = "Bad Cat Alley",
                Description = "This Alley is filled with unfriendly vicious cats that will" +
                "attack you on sight",
                Accessible = true,
            };
            gameMap.MapLocation[0, 1] = new Location()
            {
                Id = 1,
                Name = "Wild West Buchery",
                Description = " This is a very historic bucher shop  animals will often go missing around this area" +
                "be careful not to turn into sausage.",
                Accessible = true,
            };

            gameMap.MapLocation[1, 1] = new Location()
            {
                Id = 2,
                Name = "New Yourk Pound",
                Description = "Your Master has often threatend to send you to this place .",
                Accessible = true,
            };
            gameMap.MapLocation[1, 2] = new Location()
            {
                Id = 2,
                Name = "PetsMart",
                Description = "They love animals at this place they give you a free life because you chose to visit them ",
                Accessible = true,
                ModifyHealth = +50,
                ModifyLives = +1,
                
            };

            gameMap.MapLocation[2, 0] = new Location()
            {
                Id = 3,
                Name = "Marshas House",
                Description = "Marsha is a friendly person but she doesnt realize that it is not nice to take someones dog" +
                "so look out she might try to keep you for herself and dress you up",
                Accessible = false,
                ModifyHealth = 50,
                
            };
            gameMap.MapLocation[2, 1] = new Location()
            {
                Id = 4,
                Name = "The Penthouse",
                Description = "This is your owners house",
                Accessible = true,
                
            };

            return gameMap;
        }
    }
    }

