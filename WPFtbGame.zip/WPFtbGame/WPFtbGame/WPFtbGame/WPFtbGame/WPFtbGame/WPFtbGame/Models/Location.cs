﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WPFtbGame.Models
{
    public class Location
    {
        #region ENUMS

        #endregion

        #region FEILDS
        private int _id;
        private string _name;
        private string _description;
        private bool _accessible;
        private int _modifyHealth;
        private int _modifyLives;
        private string _message;
        private int _requiredHealth;
        #endregion

        #region PROPERTIES
        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }

        public int Id
        {
            get { return _id; }
            set { _id = value; }
        }

        public string Description
        {
            get { return _description; }
            set { _description = value; }
        }

        public bool Accessible
        {
            get { return _accessible; }
            set { _accessible = value; }
        }

        public int RequiredHealth
        {
            get { return _requiredHealth; }
            set { _requiredHealth = value; }
        }

        public int ModifyHealth
        {
            get { return _modifyHealth; }
            set { _modifyHealth = value; }
        }

        public int ModifyLives
        {
            get { return _modifyLives; }
            set { _modifyLives = value; }
        }

        public string Message
        {
            get { return _message; }
            set { _message = value; }
        }
        #endregion

        #region CONSTRUCTORS

        #endregion

        #region METHODS
        public bool IsAccessibleByExperienceHealth(int playerHealth)
        {
            return playerHealth >= _requiredHealth ? true : false;
        }
        #endregion
    }
}
