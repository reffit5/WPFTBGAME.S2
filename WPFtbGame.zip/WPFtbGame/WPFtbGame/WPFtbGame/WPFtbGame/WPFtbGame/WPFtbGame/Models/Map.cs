﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;



namespace WPFtbGame.Models
{
   public class Map
    {
        #region FIELDS
        private Location[,] _mapLocations;
        private GameMapCoorinates _currentLocation;
        private int _maxRows, _maxColumns;
        


        #endregion

        #region PROPERTIES
        public Location[,] MapLocation
        {
            get { return _mapLocations; }
            set { _mapLocations = value; }
        }

        public GameMapCoorinates CurrentLocation
        {
            get { return _currentLocation; }
            set { _currentLocation = value; }
        }

        #endregion

        #region CONSTRUCTORS
        public Map(int rows, int columns)
        {
            _maxRows = rows;
            _maxColumns = columns;
            _mapLocations = new Location[rows, columns];
        }

        #endregion

        #region METHODS
        public void MoveNorth()
        {
            if (_currentLocation.Row > 0)
            {
                _currentLocation.Row -= 1;
            }


        }

        public void MoveEast()
        {
            if (_currentLocation.Column < _maxColumns - 1)
            {
                _currentLocation.Column += 1;
            }
        }

        public void MoveSouth()
        {
            if (_currentLocation.Row < _maxRows - 1)
            {
                _currentLocation.Row += 1;
            }
        }

        public void MoveWest()
        {
            if (_currentLocation.Column > 0)
            {
                _currentLocation.Column -= 1;
            }
        }

        public Location NorthLocation(Player player)
        {
            Location northLocation = null;
            if (_currentLocation.Row > 0)
            {
                Location nextNorthLocation = _mapLocations[_currentLocation.Row - 1, _currentLocation.Column];
                {
                    northLocation = nextNorthLocation;
                }
            }
            return northLocation;
        }

        public Location EastLocation(Player player)
        {
            Location eastLocation = null;
            if (_currentLocation.Column < _maxColumns - 1)
            {
                Location nextEastLocation = _mapLocations[_currentLocation.Row, _currentLocation.Column + 1];
                {
                    eastLocation = nextEastLocation;
                }
            }

            return eastLocation;
        }

        public Location SouthLocation(Player player)
        {
            Location southLocation = null;
            if (_currentLocation.Row < _maxRows - 1)
            {
                Location nextSouthLocation = _mapLocations[_currentLocation.Row + 1, _currentLocation.Column];
                {
                    southLocation = nextSouthLocation;
                }
            }

            return southLocation;
        }
        public Location WestLocation(Player player)
        {
            Location westLocation = null;
            if (_currentLocation.Column > 0)
            {
                Location nextWestLocation = _mapLocations[_currentLocation.Row, _currentLocation.Column - 1];
                {
                    westLocation = nextWestLocation;
                }
            }

            return westLocation;
        }

        #endregion
    }
        }
